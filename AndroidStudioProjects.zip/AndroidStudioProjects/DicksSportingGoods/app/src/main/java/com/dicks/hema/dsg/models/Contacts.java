package com.dicks.hema.dsg.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Contacts implements Serializable {

    @SerializedName("twitter")
    private String twitter;
    @SerializedName("facebook")
    private String facebook;
    @SerializedName("facebookName")
    private String facebookName;
    @SerializedName("phone")
    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getFacebookName() {
        return facebookName;
    }

    public void setFacebookName(String facebookName) {
        this.facebookName = facebookName;
    }

}