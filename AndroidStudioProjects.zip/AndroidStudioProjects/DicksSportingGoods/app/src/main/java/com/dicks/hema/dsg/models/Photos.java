package com.dicks.hema.dsg.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Photos implements Serializable {

        @SerializedName("photoId")
        private String photoId;
        @SerializedName("createdAt  ")
        private String createdAt;
        @SerializedName("url")
        private String photourl;

        public String getPhotoId() {
            return photoId;
        }

        public void setPhotoId(String photoId) {
            this.photoId = photoId;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getPhotourl() {
            return photourl;
        }

        public void setPhotourl(String photourl) {
            this.photourl = photourl;
        }
}