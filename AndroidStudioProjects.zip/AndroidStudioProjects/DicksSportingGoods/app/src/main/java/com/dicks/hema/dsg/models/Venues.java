package com.dicks.hema.dsg.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Venues implements Serializable {


    @SerializedName("venues")
    private List<Venue> venueList;

    public List<Venue> getVenuesList() {
        return venueList;
    }

    public void setVenuesList(List<Venue> venueList) {
        this.venueList = venueList;
    }

    @Override
    public String toString() {
        return String.format("[%s]", venueList);
    }

//    @Override
//    public int compare(Object o, Object t1) {
//        return 0;
//    }

    public static class Venue implements Serializable {

        @SerializedName("id")
        private String id;
        @SerializedName("name")
        private String name;
        @SerializedName("verified")
        private String verified;
        @SerializedName("url")
        private String url;
        @SerializedName("rating")
        private String rating;

        @SerializedName("contacts")
        private List<Contacts> contacts;

        @SerializedName("photos")
        private List<Photos> photos;

        @SerializedName("location")
        private Location location;


        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getVerified() {
            return verified;
        }

        public void setVerified(String verified) {
            this.verified = verified;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getRating() {
            return rating;
        }

        public void setRating(String rating) {
            this.rating = rating;
        }

        public List<Photos> getPhotos() {
            return photos;
        }

        public void setPhotos(List<Photos> photos) {
            this.photos = photos;
        }

        public List<Contacts> getContacts() {
            return contacts;
        }

        public void setContacts(List<Contacts> contacts) {
            this.contacts = contacts;
        }

        @Override
        public String toString() {
            return String.format("[%s,%s,%s]", id, name, url);
        }

        public Location getLocation() {
            return location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }
    }

    public static class Location implements Serializable {


        @SerializedName("address")
        private String address;
        @SerializedName("city")
        private String city;
        @SerializedName("state")
        private String state;
        @SerializedName("country")
        private String country;
        @SerializedName("latitude")
        private String latitude;
        @SerializedName("longitude")
        private String longitude;
        @SerializedName("postalCode")
        private String postalCode;


        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPostalcode() {
            return postalCode;
        }

        public void setPostalcode(String postalcode) {
            this.postalCode = postalCode;
        }
    }

}
