package com.dicks.hema.dsg;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import com.dicks.hema.dsg.models.Mediator;
import com.dicks.hema.dsg.network.NetworkUtils;

/**
 * Created by hema on 12/2/17.
 */

public class MainActivity extends Activity {

    public RecyclerView recyclerView;
    public ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Creating shared pref for favourite.
        getSharedPreferences("favourite",MODE_PRIVATE);
        // Setting activity context
        Mediator.getInstance().setMainActivityContext(this);
        //getting the progressbar
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        // Connecting to the server and fetching venue details
        // Using Volley library
        NetworkUtils.connectServer();
        // getting recycler view
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);

    }
}
