package com.dicks.hema.dsg.network;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.dicks.hema.dsg.models.Mediator;
import com.dicks.hema.dsg.adapters.VenuesAdapter;
import com.dicks.hema.dsg.models.Venues;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NetworkUtils {

    private static final String VENUES_URL = "https://movesync-qa.dcsg.com/dsglabs/mobile/api/venue/";
    public static void connectServer() {
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, VENUES_URL, new JSONObject(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                // Gson to convert json data to models
                                GsonBuilder gsonBuilder = new GsonBuilder();
                                Gson gson = gsonBuilder.create();
                                final Venues venues = gson.fromJson(response.toString(), Venues.class);
                                // temp list to maintain favourite sorting
                                List<Venues.Venue> tempList = new ArrayList<>();
                                for(int i = 0; i < venues.getVenuesList().size(); i++) {
                                    if(!Mediator.getInstance().getMainActivityContext().getSharedPreferences("favourite",Mediator.getInstance().getMainActivityContext().MODE_PRIVATE).getString("favourite","").isEmpty() &&
                                            Mediator.getInstance().getMainActivityContext().getSharedPreferences("favourite",Mediator.getInstance().getMainActivityContext().MODE_PRIVATE).getString("favourite","")
                                                    .equalsIgnoreCase(venues.getVenuesList().get(i).getId())) {
                                        tempList.add(0,venues.getVenuesList().get(i));
                                    } else tempList.add(i,venues.getVenuesList().get(i));

                                }

                                VenuesAdapter venuesAdapter = new VenuesAdapter(tempList);
                                if(Mediator.getInstance().getMainActivityContext() != null) {
                                    // Setting adapter to recycler view to display venues
                                    Mediator.getInstance().getMainActivityContext().recyclerView.setAdapter(venuesAdapter);
                                    Mediator.getInstance().getMainActivityContext().recyclerView.setLayoutManager(new LinearLayoutManager(Mediator.getInstance().getMainActivityContext()));
                                    // Hiding progressbar after loading
                                    Mediator.getInstance().getMainActivityContext().progressBar.setVisibility(View.GONE);
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Mediator.getInstance().getMainActivityContext(),"Can't connect to server",Toast.LENGTH_LONG).show();
                    Mediator.getInstance().getMainActivityContext().progressBar.setVisibility(View.GONE);
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(Mediator.getInstance().getMainActivityContext());
            requestQueue.add(jsonObjectRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
