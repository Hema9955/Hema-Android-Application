package com.dicks.hema.dsg;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

import com.dicks.hema.dsg.models.Mediator;
import com.dicks.hema.dsg.models.Photos;
import com.dicks.hema.dsg.models.Venues;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class GalleryViewActivity extends Activity {

    Venues.Venue venueList;
    List<String> galleryUrls;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gallery_layout);

        if(getIntent() != null && getIntent().getSerializableExtra("photos") != null) {
            galleryUrls = new ArrayList<>();
            venueList = (Venues.Venue) getIntent().getSerializableExtra("photos");
            for (Photos photos : venueList.getPhotos()) {
                galleryUrls.add(photos.getPhotourl());
            }

            Gallery gallery = (Gallery) findViewById(R.id.gallery);
            final ImageView selectedImage = (ImageView) findViewById(R.id.imageView);
            gallery.setSpacing(2);
            final GalleryImageAdapter galleryImageAdapter = new GalleryImageAdapter(this,galleryUrls);
            gallery.setAdapter(galleryImageAdapter);

            Picasso.with(GalleryViewActivity.this).load(galleryUrls.get(0))
                    .resize(300,300).into(selectedImage);

            gallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                    Picasso.with(GalleryViewActivity.this).load(galleryUrls.get(position))
                            .resize(300,300).into(selectedImage);
                }
            });

        } else return;

    }

    public class GalleryImageAdapter extends BaseAdapter
    {

        private Context mContext;
        List<String> galleryUrls;

        public GalleryImageAdapter(Context context , List<String> galleryUrls)
        {
            this.mContext = context;
            this.galleryUrls = galleryUrls;
        }

        public int getCount() {
            return galleryUrls.size();
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            // TODO Auto-generated method stub
            ImageView imageView = new ImageView(mContext);
            imageView.setLayoutParams(new Gallery.LayoutParams(200, 200));
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            Picasso.with(Mediator.getInstance().getMainActivityContext()).load(galleryUrls.get(i))
                    .resize(200,200).into(imageView);
            return imageView;
        }
    }

}
