package com.dicks.hema.dsg;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.dicks.hema.dsg.adapters.VenuesAdapter;
import com.dicks.hema.dsg.models.Mediator;
import com.dicks.hema.dsg.models.Venues;


import java.util.ArrayList;
import java.util.List;

public class DetailsActivity extends Activity {

    Venues.Venue venue;
    int position;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_activity_layout);
        final Context context = this;
        try {

            if(getIntent() != null && getIntent().getSerializableExtra("details") != null) {
                venue = (Venues.Venue) getIntent().getSerializableExtra("details");
                position = getIntent().getIntExtra("position",0);
            } else return;


            TextView detail_venue_name = (TextView)findViewById(R.id.detail_venue_name);
            TextView detail_rating = (TextView)findViewById(R.id.detail_rating);
            TextView detail_url = (TextView)findViewById(R.id.detail_url);
            TextView detail_location = (TextView)findViewById(R.id.detail_location);
            TextView detail_phone = (TextView)findViewById(R.id.detail_contacts);
            TextView favourite = (TextView)findViewById(R.id.favourite);
            TextView gallery = (TextView)findViewById(R.id.gallery);
            gallery.setVisibility(View.GONE);

            if(venue.getPhotos().size() > 0) {
                gallery.setVisibility(View.VISIBLE);
                gallery.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent galleryIntent = new Intent(DetailsActivity.this, GalleryViewActivity.class);
                        galleryIntent.putExtra("photos", venue);
                        startActivity(galleryIntent);
                    }
                });
            }

            favourite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences preferences = getSharedPreferences("favourite",MODE_PRIVATE);
                    if(preferences != null) {
                        SharedPreferences.Editor editor = preferences.edit().putString("favourite",venue.getId());
                        editor.commit();
                        Toast.makeText(DetailsActivity.this,"Favourite has set successfully.", Toast.LENGTH_LONG).show();
                        List<Venues.Venue> temporaryList = new ArrayList<>();
                        for(int i = 0; i < VenuesAdapter.venueList.size() ; i++) {
                            if(!context.getSharedPreferences("favourite",context.MODE_PRIVATE).getString("favourite","").isEmpty() &&
                                    context.getSharedPreferences("favourite",context.MODE_PRIVATE).getString("favourite","")
                                            .equalsIgnoreCase(VenuesAdapter.venueList.get(i).getId())) {
                                temporaryList.add(0,VenuesAdapter.venueList.get(i));
                            } else temporaryList.add(i,VenuesAdapter.venueList.get(i));

                        }

                        VenuesAdapter venuesAdapter = new VenuesAdapter(temporaryList);
                        Mediator.getInstance().getMainActivityContext().recyclerView.setAdapter(venuesAdapter);
                        Mediator.getInstance().getMainActivityContext().recyclerView.getAdapter().notifyDataSetChanged();
                        finish();
                    }
                }
            });

            detail_venue_name.setText(venue.getName());
            detail_rating.setText(venue.getRating());
            detail_url.setText(venue.getUrl());
            detail_location.setText(venue.getLocation().getAddress() +
              ", " + venue.getLocation().getCity() +
              ", "+ venue.getLocation().getState() +
              ", "+ venue.getLocation().getCountry() +
                    ", "+ venue.getLocation().getPostalcode()
            );
            detail_phone.setText("Phone - " + venue.getContacts().get(0).getPhone()+
                    "\n" + "Facebook - " + venue.getContacts().get(0).getFacebook() +
                    "\n" + "Facebook Name - " + venue.getContacts().get(0).getFacebookName().toLowerCase() +
                            "\n"+ "Twitter - " +venue.getContacts().get(0).getTwitter());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
