package com.dicks.hema.dsg.adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.dicks.hema.dsg.DetailsActivity;
import com.dicks.hema.dsg.R;
import com.dicks.hema.dsg.models.Mediator;

import com.dicks.hema.dsg.models.Venues;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class VenuesAdapter extends RecyclerView.Adapter<VenuesAdapter.VenuesHolder>  {

    public static List<Venues.Venue> venueList = new ArrayList<>();
    public VenuesAdapter(List<Venues.Venue> venues) {
        this.venueList = venues;
    }

    @Override
    public VenuesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(Mediator.getInstance().getMainActivityContext()).inflate(R.layout.list_item_layout, null);
        return new VenuesHolder(view);
    }

    @Override
    public void onBindViewHolder(VenuesHolder holder, final int position) {
        try {
            if(!Mediator.getInstance().getMainActivityContext().getSharedPreferences("favourite",Mediator.getInstance().getMainActivityContext().MODE_PRIVATE).getString("favourite","").isEmpty() &&
                    Mediator.getInstance().getMainActivityContext().getSharedPreferences("favourite",Mediator.getInstance().getMainActivityContext().MODE_PRIVATE).getString("favourite","")
                            .equalsIgnoreCase(venueList.get(position).getId())) {
                holder.favourite.setImageResource(android.R.drawable.btn_star_big_on); // Favourite enable
            } else holder.favourite.setImageResource(android.R.drawable.btn_star_big_off); // Favourite disable
            holder.venue_name.setText(venueList.get(position).getName());
            holder.venue_rating.setText("Rating - " +venueList.get(position).getRating());

            if(venueList.get(position).getLocation() != null)
                holder.venue_city.setText("City - " + venueList.get(position).getLocation().getCity());
            else holder.venue_city.setVisibility(View.GONE);
            // Picasso library to load images from url and image caching
            if(!venueList.get(position).getPhotos().get(0).getPhotourl().isEmpty())
                Picasso.with(Mediator.getInstance().getMainActivityContext()).load(venueList.get(position).getPhotos().get(0).getPhotourl())
                        .resize(200,200).into(holder.imgView);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return venueList.size();
    }

    public class VenuesHolder extends RecyclerView.ViewHolder {

        TextView venue_name,venue_rating,venue_city;
        ImageView imgView,favourite;

        public VenuesHolder(View itemView) {
            super(itemView);
            venue_name = (TextView) itemView.findViewById(R.id.venue_name);
            venue_rating = (TextView) itemView.findViewById(R.id.venue_rating);
            venue_city = (TextView) itemView.findViewById(R.id.venue_city);
            imgView = (ImageView)itemView.findViewById(R.id.imgView);
            favourite = (ImageView)itemView.findViewById(R.id.favourite);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent detailsIntent = new Intent(Mediator.getInstance().getMainActivityContext(), DetailsActivity.class);
                    detailsIntent.putExtra("position", getAdapterPosition());
                    detailsIntent.putExtra("details", venueList.get(getAdapterPosition()));
                    Mediator.getInstance().getMainActivityContext().startActivity(detailsIntent);
                }
            });
        }
    }
}
